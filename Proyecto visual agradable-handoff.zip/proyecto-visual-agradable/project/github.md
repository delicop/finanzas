repo: delicop/finanzas
branch: main
path: frontend/src

## Last sync

date: 2026-09-18T15:17:00Z

### Updated in this project

- Rediseño completo con el sistema Classical: las 11 vistas del repo + 5 modales, escritorio y teléfono.
- Vistas nuevas incorporadas: "Se repiten" (recurrentes), Por confirmar, abonos y acuerdo de cuotas, traslados, "Me prestaron", contrapartes y avisos al celular.
- El chat del asistente deja la estética de WhatsApp: ahora es una consulta editorial.

## Screen map

| Pantalla del proyecto | Archivos del repo |
| --- | --- |
| Rediseño · Resumen | paginas/Dashboard.jsx, componentes/RecurrentesPendientes.jsx, componentes/FechaCobro.jsx, componentes/Layout.jsx, lib/formato.js |
| Rediseño · Movimientos | paginas/Movimientos.jsx, lib/formato.js (ETIQUETAS_TIPO, estiloMonto, mensajeDeCobro) |
| Rediseño · Se repiten | paginas/Recurrentes.jsx, componentes/RecurrentesPendientes.jsx |
| Rediseño · Categorías | paginas/Categorias.jsx |
| Rediseño · Medios de pago | paginas/MediosPago.jsx |
| Rediseño · Login | paginas/Login.jsx |
| Rediseño · Asistente | componentes/BurbujaAsistente.jsx, componentes/BurbujaMensaje.jsx, componentes/PropuestaAgente.jsx |
| Rediseño · Negocio | paginas/Negocio.jsx |
| Rediseño · Clientes | paginas/Clientes.jsx |
| Rediseño · Planes | paginas/Planes.jsx |
| Rediseño · Errores | paginas/Errores.jsx |
| Rediseño · Modal nuevo movimiento / deuda | componentes/MovimientoForm.jsx |
| Rediseño · Modal abonos y acuerdo | componentes/ModalAbonos.jsx |
| Rediseño · Modal avisos | componentes/Notificaciones.jsx, componentes/AvisosCelular.jsx |
| Rediseño · Modal registrar cobro | paginas/Negocio.jsx (FormularioPago) |
| Finanzas — Actual (recreación oscura) | estilos.css + las páginas anteriores al cambio |
| Finanzas — Propuestas (1a/1b/1c) | derivadas de las anteriores + _ds/classical-e22995e1 |

## Sync history

- 2026-09-18T14:52:00Z — primera lectura: recreación del estado anterior y tres direcciones visuales.
